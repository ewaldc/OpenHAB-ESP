#define NUM_SITEMAPS 2
char SiteMaps[] = "[{\
  \"name\": \"demo\",\
  \"label\": \"Main Menu\",\
  \"link\": \"http://###################/rest/sitemaps/demo\"\
 }, {\
  \"name\": \"_default\",\
  \"label\": \"Home\",\
  \"link\": \"http://###################/rest/sitemaps/_default\"\
 }\
]";
#define SITEMAPSJSONBUFFER 144

char* SiteMap[] = {"Demo", "{\
 \"id\": \"demo\",\
 \"title\": \"Main Menu\",\
 \"link\": \"http://###################/rest/sitemaps/demo/demo\",\
 \"leaf\": true,\
 \"widgets\": [{\
   \"widgetId\": \"demo_0\",\
   \"type\": \"Frame\",\
   \"label\": \"\",\
   \"icon\": \"frame\",\
   \"mappings\": [],\
   \"widgets\": [{\
     \"widgetId\": \"demo_0_0\",\
     \"type\": \"Group\",\
     \"label\": \"First Floor\",\
     \"icon\": \"firstfloor\",\
     \"mappings\": [],\
     \"item\": {\
      \"members\": [],\
      \"link\": \"http://###################/rest/items/gFF\",\
      \"state\": \"UNDEF\",\
      \"type\": \"Group\",\
      \"name\": \"gFF\",\
      \"label\": \"First Floor\",\
      \"category\": \"firstfloor\",\
      \"tags\": [],\
      \"groupNames\": []\
     },\
     \"linkedPage\": {\
      \"id\": \"0000\",\
      \"title\": \"First Floor\",\
      \"icon\": \"firstfloor\",\
      \"link\": \"http://###################/rest/sitemaps/demo/0000\",\
      \"leaf\": false\
     },\
     \"widgets\": []\
    }, {\
     \"widgetId\": \"demo_0_0_1\",\
     \"type\": \"Group\",\
     \"label\": \"Ground Floor\",\
     \"icon\": \"groundfloor\",\
     \"mappings\": [],\
     \"item\": {\
      \"members\": [],\
      \"link\": \"http://###################/rest/items/gGF\",\
      \"state\": \"UNDEF\",\
      \"type\": \"Group\",\
      \"name\": \"gGF\",\
      \"label\": \"Ground Floor\",\
      \"category\": \"groundfloor\",\
      \"tags\": [],\
      \"groupNames\": []\
     },\
     \"linkedPage\": {\
      \"id\": \"0001\",\
      \"title\": \"Ground Floor\",\
      \"icon\": \"groundfloor\",\
      \"link\": \"http://###################/rest/sitemaps/demo/0001\",\
      \"leaf\": false\
     },\
     \"widgets\": []\
    }, {\
     \"widgetId\": \"demo_0_0_1_2\",\
     \"type\": \"Group\",\
     \"label\": \"Cellar\",\
     \"icon\": \"cellar\",\
     \"mappings\": [],\
     \"item\": {\
      \"members\": [],\
      \"link\": \"http://###################/rest/items/gC\",\
      \"state\": \"UNDEF\",\
      \"type\": \"Group\",\
      \"name\": \"gC\",\
      \"label\": \"Cellar\",\
      \"category\": \"cellar\",\
      \"tags\": [],\
      \"groupNames\": []\
     },\
     \"linkedPage\": {\
      \"id\": \"0002\",\
      \"title\": \"Cellar\",\
      \"icon\": \"cellar\",\
      \"link\": \"http://###################/rest/sitemaps/demo/0002\",\
      \"leaf\": true\
     },\
     \"widgets\": []\
    }, {\
     \"widgetId\": \"demo_0_0_1_2_3\",\
     \"type\": \"Group\",\
     \"label\": \"Garden\",\
     \"icon\": \"garden\",\
     \"mappings\": [],\
     \"item\": {\
      \"members\": [],\
      \"link\": \"http://###################/rest/items/Garden\",\
      \"state\": \"UNDEF\",\
      \"type\": \"Group\",\
      \"name\": \"Garden\",\
      \"label\": \"Garden\",\
      \"category\": \"garden\",\
      \"tags\": [],\
      \"groupNames\": []\
     },\
     \"linkedPage\": {\
      \"id\": \"0003\",\
      \"title\": \"Garden\",\
      \"icon\": \"garden\",\
      \"link\": \"http://###################/rest/sitemaps/demo/0003\",\
      \"leaf\": true\
     },\
     \"widgets\": []\
    }\
   ]\
  }, {\
   \"widgetId\": \"demo_1\",\
   \"type\": \"Frame\",\
   \"label\": \"Weather\",\
   \"icon\": \"frame\",\
   \"mappings\": [],\
   \"widgets\": [{\
     \"widgetId\": \"demo_1_0\",\
     \"type\": \"Text\",\
     \"label\": \"Outside Temperature [6.0 °C]\",\
     \"icon\": \"temperature\",\
     \"valuecolor\": \"lightgray\",\
     \"mappings\": [],\
     \"item\": {\
      \"link\": \"http://###################/rest/items/Weather_Temperature\",\
      \"state\": \"6\",\
      \"stateDescription\": {\
       \"pattern\": \"%.1f °C\",\
       \"readOnly\": false,\
       \"options\": []\
      },\
      \"type\": \"Number\",\
      \"name\": \"Weather_Temperature\",\
      \"label\": \"Outside Temperature\",\
      \"category\": \"temperature\",\
      \"tags\": [],\
      \"groupNames\": [\"Weather\", \"Weather_Chart\"]\
     },\
     \"linkedPage\": {\
      \"id\": \"0100\",\
      \"title\": \"Outside Temperature [6.0 °C]\",\
      \"icon\": \"temperature\",\
      \"link\": \"http://###################/rest/sitemaps/demo/0100\",\
      \"leaf\": false\
     },\
     \"widgets\": []\
    }, {\
     \"widgetId\": \"demo_1_0_1\",\
     \"type\": \"Text\",\
     \"label\": \"Astronomical Data\",\
     \"icon\": \"sun\",\
     \"mappings\": [],\
     \"linkedPage\": {\
      \"id\": \"0101\",\
      \"title\": \"Astronomical Data\",\
      \"icon\": \"sun\",\
      \"link\": \"http://###################/rest/sitemaps/demo/0101\",\
      \"leaf\": true\
     },\
     \"widgets\": []\
    }\
   ]\
  }, {\
   \"widgetId\": \"demo_2\",\
   \"type\": \"Frame\",\
   \"label\": \"Demo\",\
   \"icon\": \"frame\",\
   \"mappings\": [],\
   \"widgets\": [{\
     \"widgetId\": \"demo_2_0\",\
     \"type\": \"Text\",\
     \"label\": \"Date [Friday, 10.03.2017]\",\
     \"icon\": \"calendar\",\
     \"mappings\": [],\
     \"item\": {\
      \"link\": \"http://###################/rest/items/CurrentDate\",\
      \"state\": \"2017-03-10T11:12:01.939+0100\",\
      \"stateDescription\": {\
       \"pattern\": \"%1\tA, %1\td.%1\tm.%1\tY\",\
       \"readOnly\": false,\
       \"options\": []\
      },\
      \"type\": \"DateTime\",\
      \"name\": \"CurrentDate\",\
      \"label\": \"Date\",\
      \"category\": \"calendar\",\
      \"tags\": [],\
      \"groupNames\": []\
     },\
     \"widgets\": []\
    }, {\
     \"widgetId\": \"demo_2_0_1\",\
     \"type\": \"Text\",\
     \"label\": \"Group Demo\",\
     \"icon\": \"firstfloor\",\
     \"mappings\": [],\
     \"linkedPage\": {\
      \"id\": \"0201\",\
      \"title\": \"Group Demo\",\
      \"icon\": \"firstfloor\",\
      \"link\": \"http://###################/rest/sitemaps/demo/0201\",\
      \"leaf\": false\
     },\
     \"widgets\": []\
    }, {\
     \"widgetId\": \"demo_2_0_1_2\",\
     \"type\": \"Text\",\
     \"label\": \"Widget Overview\",\
     \"icon\": \"chart\",\
     \"mappings\": [],\
     \"linkedPage\": {\
      \"id\": \"0202\",\
      \"title\": \"Widget Overview\",\
      \"icon\": \"chart\",\
      \"link\": \"http://###################/rest/sitemaps/demo/0202\",\
      \"leaf\": false\
     },\
     \"widgets\": []\
    }, {\
     \"widgetId\": \"demo_2_0_1_2_3\",\
     \"type\": \"Text\",\
     \"label\": \"Multimedia\",\
     \"icon\": \"video\",\
     \"mappings\": [],\
     \"linkedPage\": {\
      \"id\": \"0203\",\
      \"title\": \"Multimedia\",\
      \"icon\": \"video\",\
      \"link\": \"http://###################/rest/sitemaps/demo/0203\",\
      \"leaf\": false\
     },\
     \"widgets\": []\
    }\
   ]\
  }\
 ]\
}",\
"_default", "{\
 \"name\": \"_default\",\
 \"label\": \"Home\",\
 \"link\": \"http://###################/rest/sitemaps/_default\",\
 \"homepage\": {\
  \"id\": \"_default\",\
  \"title\": \"Home\",\
  \"link\": \"http://###################/rest/sitemaps/_default/_default\",\
  \"leaf\": false,\
  \"widgets\": [{\
    \"widgetId\": \"_default_0\",\
    \"type\": \"Frame\",\
    \"label\": \"Things\",\
    \"icon\": \"frame\",\
    \"mappings\": [],\
    \"widgets\": [{\
      \"widgetId\": \"_default_0_0\",\
      \"type\": \"Text\",\
      \"label\": \"\",\
      \"icon\": \"player\",\
      \"mappings\": [],\
      \"linkedPage\": {\
       \"id\": \"0000\",\
       \"title\": \"\",\
       \"icon\": \"player\",\
       \"link\": \"http://###################/rest/sitemaps/_default/0000\",\
       \"leaf\": true,\
       \"widgets\": [{\
         \"widgetId\": \"0000_0\",\
         \"type\": \"Text\",\
         \"label\": \"Date [Friday, 10.03.2017]\",\
         \"icon\": \"calendar\",\
         \"mappings\": [],\
         \"item\": {\
          \"link\": \"http://###################/rest/items/CurrentDate\",\
          \"state\": \"2017-03-10T12:03:01.938+0100\",\
          \"stateDescription\": {\
           \"pattern\": \"%1\tA, %1\td.%1\tm.%1\tY\",\
           \"readOnly\": false,\
           \"options\": []\
          },\
          \"type\": \"DateTime\",\
          \"name\": \"CurrentDate\",\
          \"label\": \"Date\",\
          \"category\": \"calendar\",\
          \"tags\": [],\
          \"groupNames\": []\
         },\
         \"widgets\": []\
        }\
       ]\
      },\
      \"widgets\": []\
     }, {\
      \"widgetId\": \"_default_0_0_1\",\
      \"type\": \"Text\",\
      \"label\": \"\",\
      \"icon\": \"player\",\
      \"mappings\": [],\
      \"linkedPage\": {\
       \"id\": \"0001\",\
       \"title\": \"\",\
       \"icon\": \"player\",\
       \"link\": \"http://###################/rest/sitemaps/_default/0001\",\
       \"leaf\": true,\
       \"widgets\": [{\
         \"widgetId\": \"0001_0\",\
         \"type\": \"Text\",\
         \"label\": \"Outside Temperature [6.0 °C]\",\
         \"icon\": \"temperature\",\
         \"mappings\": [],\
         \"item\": {\
          \"link\": \"http://###################/rest/items/Weather_Temperature\",\
          \"state\": \"6\",\
          \"stateDescription\": {\
           \"pattern\": \"%.1f °C\",\
           \"readOnly\": false,\
           \"options\": []\
          },\
          \"type\": \"Number\",\
          \"name\": \"Weather_Temperature\",\
          \"label\": \"Outside Temperature\",\
          \"category\": \"temperature\",\
          \"tags\": [],\
          \"groupNames\": [\"Weather\", \"Weather_Chart\"]\
         },\
         \"widgets\": []\
        }, {\
         \"widgetId\": \"0001_1\",\
         \"type\": \"Text\",\
         \"label\": \"Humidity [- %]\",\
         \"icon\": \"humidity\",\
         \"mappings\": [],\
         \"item\": {\
          \"link\": \"http://###################/rest/items/yahooweather_weather_berlin_humidity\",\
          \"state\": \"NULL\",\
          \"stateDescription\": {\
           \"pattern\": \"%d %%\",\
           \"readOnly\": true,\
           \"options\": []\
          },\
          \"type\": \"Number\",\
          \"name\": \"yahooweather_weather_berlin_humidity\",\
          \"label\": \"Humidity\",\
          \"category\": \"Humidity\",\
          \"tags\": [],\
          \"groupNames\": []\
         },\
         \"widgets\": []\
        }\
       ]\
      },\
      \"widgets\": []\
     }, {\
      \"widgetId\": \"_default_0_0_1_2\",\
      \"type\": \"Text\",\
      \"label\": \"\",\
      \"icon\": \"player\",\
      \"mappings\": [],\
      \"linkedPage\": {\
       \"id\": \"0002\",\
       \"title\": \"\",\
       \"icon\": \"player\",\
       \"link\": \"http://###################/rest/sitemaps/_default/0002\",\
       \"leaf\": true,\
       \"widgets\": [{\
         \"widgetId\": \"0002_0\",\
         \"type\": \"Text\",\
         \"label\": \"Sunrise [06:34]\",\
         \"icon\": \"sunrise\",\
         \"mappings\": [],\
         \"item\": {\
          \"link\": \"http://###################/rest/items/Sunrise_Time\",\
          \"state\": \"2017-03-10T06:34:00.000+0100\",\
          \"stateDescription\": {\
           \"pattern\": \"%1\tH:%1\tM\",\
           \"readOnly\": false,\
           \"options\": []\
          },\
          \"type\": \"DateTime\",\
          \"name\": \"Sunrise_Time\",\
          \"label\": \"Sunrise\",\
          \"category\": \"sunrise\",\
          \"tags\": [],\
          \"groupNames\": []\
         },\
         \"widgets\": []\
        }, {\
         \"widgetId\": \"0002_1\",\
         \"type\": \"Text\",\
         \"label\": \"Sunset [17:59]\",\
         \"icon\": \"sunset\",\
         \"mappings\": [],\
         \"item\": {\
          \"link\": \"http://###################/rest/items/Sunset_Time\",\
          \"state\": \"2017-03-10T17:59:00.000+0100\",\
          \"stateDescription\": {\
           \"pattern\": \"%1\tH:%1\tM\",\
           \"readOnly\": false,\
           \"options\": []\
          },\
          \"type\": \"DateTime\",\
          \"name\": \"Sunset_Time\",\
          \"label\": \"Sunset\",\
          \"category\": \"sunset\",\
          \"tags\": [],\
          \"groupNames\": []\
         },\
         \"widgets\": []\
        }, {\
         \"widgetId\": \"0002_2\",\
         \"type\": \"Text\",\
         \"label\": \"Sun Azimuth [175.74 °]\",\
         \"icon\": \"sun\",\
         \"mappings\": [],\
         \"item\": {\
          \"link\": \"http://###################/rest/items/Sun_Azimuth\",\
          \"state\": \"175.74\",\
          \"stateDescription\": {\
           \"pattern\": \"%.2f °\",\
           \"readOnly\": true,\
           \"options\": []\
          },\
          \"type\": \"Number\",\
          \"name\": \"Sun_Azimuth\",\
          \"label\": \"Sun Azimuth\",\
          \"category\": \"sun\",\
          \"tags\": [],\
          \"groupNames\": []\
         },\
         \"widgets\": []\
        }, {\
         \"widgetId\": \"0002_3\",\
         \"type\": \"Text\",\
         \"label\": \"Sun Elevation [33.35 °]\",\
         \"icon\": \"sun\",\
         \"mappings\": [],\
         \"item\": {\
          \"link\": \"http://###################/rest/items/Sun_Elevation\",\
          \"state\": \"33.35\",\
          \"stateDescription\": {\
           \"pattern\": \"%.2f °\",\
           \"readOnly\": true,\
           \"options\": []\
          },\
          \"type\": \"Number\",\
          \"name\": \"Sun_Elevation\",\
          \"label\": \"Sun Elevation\",\
          \"category\": \"sun\",\
          \"tags\": [],\
          \"groupNames\": []\
         },\
         \"widgets\": []\
        }\
       ]\
      },\
      \"widgets\": []\
     }, {\
      \"widgetId\": \"_default_0_0_1_2_3\",\
      \"type\": \"Text\",\
      \"label\": \"\",\
      \"icon\": \"player\",\
      \"mappings\": [],\
      \"linkedPage\": {\
       \"id\": \"0003\",\
       \"title\": \"\",\
       \"icon\": \"player\",\
       \"link\": \"http://###################/rest/sitemaps/_default/0003\",\
       \"leaf\": true,\
       \"widgets\": [{\
         \"widgetId\": \"0003_0\",\
         \"type\": \"Text\",\
         \"label\": \"Moon Phase\",\
         \"icon\": \"moon\",\
         \"mappings\": [],\
         \"item\": {\
          \"link\": \"http://###################/rest/items/Moon_Phase\",\
          \"state\": \"WAXING_GIBBOUS\",\
          \"stateDescription\": {\
           \"readOnly\": true,\
           \"options\": [{\
             \"value\": \"NEW\",\
             \"label\": \"New moon\"\
            }, {\
             \"value\": \"WAXING_CRESCENT\",\
             \"label\": \"Waxing crescent\"\
            }, {\
             \"value\": \"FIRST_QUARTER\",\
             \"label\": \"First quarter\"\
            }, {\
             \"value\": \"WAXING_GIBBOUS\",\
             \"label\": \"Waxing gibbous\"\
            }, {\
             \"value\": \"FULL\",\
             \"label\": \"Full moon\"\
            }, {\
             \"value\": \"WANING_GIBBOUS\",\
             \"label\": \"Wanning gibbous\"\
            }, {\
             \"value\": \"THIRD_QUARTER\",\
             \"label\": \"Third quarter\"\
            }, {\
             \"value\": \"WANING_CRESCENT\",\
             \"label\": \"Waning crescent\"\
            }\
           ]\
          },\
          \"type\": \"String\",\
          \"name\": \"Moon_Phase\",\
          \"label\": \"Moon Phase\",\
          \"category\": \"moon\",\
          \"tags\": [],\
          \"groupNames\": []\
         },\
         \"widgets\": []\
        }, {\
         \"widgetId\": \"0003_1\",\
         \"type\": \"Text\",\
         \"label\": \"Moon Azimuth [22.72 °]\",\
         \"icon\": \"moon\",\
         \"mappings\": [],\
         \"item\": {\
          \"link\": \"http://###################/rest/items/Moon_Azimuth\",\
          \"state\": \"22.72\",\
          \"stateDescription\": {\
           \"pattern\": \"%.2f °\",\
           \"readOnly\": true,\
           \"options\": []\
          },\
          \"type\": \"Number\",\
          \"name\": \"Moon_Azimuth\",\
          \"label\": \"Moon Azimuth\",\
          \"category\": \"moon\",\
          \"tags\": [],\
          \"groupNames\": []\
         },\
         \"widgets\": []\
        }, {\
         \"widgetId\": \"0003_2\",\
         \"type\": \"Text\",\
         \"label\": \"Moon Elevation [-22.95 °]\",\
         \"icon\": \"moon\",\
         \"mappings\": [],\
         \"item\": {\
          \"link\": \"http://###################/rest/items/Moon_Elevation\",\
          \"state\": \"-22.95\",\
          \"stateDescription\": {\
           \"pattern\": \"%.2f °\",\
           \"readOnly\": true,\
           \"options\": []\
          },\
          \"type\": \"Number\",\
          \"name\": \"Moon_Elevation\",\
          \"label\": \"Moon Elevation\",\
          \"category\": \"moon\",\
          \"tags\": [],\
          \"groupNames\": []\
         },\
         \"widgets\": []\
        }\
       ]\
      },\
      \"widgets\": []\
     }\
    ]\
   }\
  ]\
 }\
}"};
#define SITEMAPJSONBUFFER = 512

