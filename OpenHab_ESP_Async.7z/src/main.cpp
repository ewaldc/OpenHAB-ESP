//#define ArduinoJsonDebug
#define OpenHABDebug
//#include <ArduinoJson.h>
#include <pgmspace.h>

// WiFi parameters
static const PROGMEM char *softAPssid = "ETesp2";
//static const PROGMEM char *ssid = "EThomeZX";
static const PROGMEM char *ssid = "ETspTP";
//static const PROGMEM char *ssid = "EThotspot";
static const PROGMEM char *passphrase = "3cwVXZkJGMl1zOyB2Y=E";  //base64 encoded
const PROGMEM char *allowedMAC[] = {"a0:cb:fd:d0:f3:52", "60:57:18:fd:30:d1", "b4:ef:fa:9d:d2:2c", "24:0a:64:b0:84:05", ""};

#include "OpenHAB.h"
// Global parameters
#define LISTEN_PORT 8080                // The port to listen for incoming TCP connections
OpenHab OpenHabServer(LISTEN_PORT);   // Create an instance of the OpenHAB server

void setup(void) {
  Serial.begin(115200);
  while (!Serial) {} // Wait for serial port initialization
  Serial.println();  //Clear some garbage that may be printed to the serial console
  //ets_intr_lock(); // all interupt off
  //wdt_disable();
  //ESP.wdtEnable(65535);
  delay(500);
  /*
  DynamicJsonDocument jsonDoc(capacity);
  deserializeJson(jsonDoc, json);
  SendJson (jsonDoc.as<JsonVariant>());
  */
  DbgPrintln(F("free heap memory: "), ESP.getFreeHeap());
    
  if (!OpenHabServer.Init(ssid, softAPssid, passphrase, allowedMAC))
    DbgPrintln(F("Server init failed"));
  else {    
    //wifi_set_event_handler_cb(wifiEventHandler);
    OpenHabServer.StartServer();	// Start the server
    DbgPrintln(F("HTTP server started"));
  }
}

void loop() {  // Handle REST calls
  //OpenHabServer.HandleClient();
}
