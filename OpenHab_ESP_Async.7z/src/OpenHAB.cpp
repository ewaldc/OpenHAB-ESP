#include "OpenHAB.h"

//namespace OpenHab {
OpenHab::OpenHab(const int port) : 
	_server(port),
	_port(port),
	//_print(_server.client()),
	_itemList(nullptr),
	_groupList(nullptr)
	{}

/*
JsonVariant OpenHab::cloneInPlace(JsonBuffer& jb, JsonVariant prototype) {
	if (prototype.is<JsonObject>()) {
		const JsonObject& protoObj = prototype;
		JsonObject& newObj = jb.createObject();
		for (const auto& kvp : protoObj) {
			newObj[kvp.key] = cloneInPlace(jb, kvp.value);
			if (!strcmp(kvp.key, "leaf") && (kvp.value.as<bool>())) break;
		}
		return newObj;
	}
	if (prototype.is<JsonArray>()) {
		const JsonArray& protoArr = prototype;
		JsonArray& newArr = jb.createArray();
		for (const auto& elem : protoArr) newArr.add(cloneInPlace(jb, elem));
		return newArr;
	}
	if (prototype.is<char*>()) return prototype.as<char*>(); //jb.strdup(prototype.as<char*>());
	return prototype;
}
 */

/* 
JsonVariant OpenHab::getNestedMember(const JsonVariant prototype, const char *key) {
	DbgPrintln(F("getNestedMember: key: "), key);
	if (prototype.is<JsonObject>()) {
		const JsonObject& obj = prototype;
		for (const JsonPair pair : obj) {
			DbgPrintln("key:", pair.key().c_str());
			if (!strcmp(pair.key().c_str(), key)) {
				DbgPrintln("Found key:", key);
				return pair.value();
			}
			getNestedMember(pair.value().as<JsonObject>(), key);
			for (auto arr : pair.value().as<JsonArray>()) {
				getNestedMember(arr.as<JsonVariant>(), key); }
		}
	} else if (prototype.is<JsonArray>()) {
		const JsonArray& arr = prototype;
		for (const auto& elem : arr) getNestedMember(elem.as<JsonVariant>(), key); //, parent);
	}
	return DynamicJsonDocument(0).as<JsonVariant>();
}
*/
static void printTm(const __FlashStringHelper *s, const tm* tm) {
  Serial.print(s);
  PTM(isdst); PTM(yday); PTM(wday);
  PTM(year);  PTM(mon);  PTM(mday);
  PTM(hour);  PTM(min);  PTM(sec);
}

FORCE_INLINE static void convDateTimeJavaToC(char *dateTime) {
	String dateTimeStr = dateTime;
	dateTimeStr.replace("1$t", "");
	strncpy(dateTime, dateTimeStr.c_str(), dateTimeStr.length() + 1);
}

void OpenHab::SSEEventHandler(AsyncWebServerRequest &request) {
	DbgPrintRequest(request, F("SSEEventHandler"));
	//event: eventdata: { "TYPE":"ALIVE","sitemapName":"demos","pageId":"demos"}

}

//void OpenHab::serverSentEventHeader(AsyncAbstractResponse &response) {
void OpenHab::serverSentEventHeader(AsyncResponseStream &response) {	
	
  //client.write(PSTR("Content-Type: text/event-stream;charset=UTF-8"));
  //response.addHeader(PSTR("Connection"), PSTR("close")); // the connection will be closed after completion of the response
  response.addHeader(PSTR("Access-Control-Allow-Origin"), PSTR("*"));  // allow any connection. We don't want to host all of the website ;-)
  response.addHeader(PSTR("Cache-Control"), PSTR("no-cache"));  // refresh the page automatically every 5 sec
}

/*

void OpenHab::SSEKeepAlive(const char *sitemap, const char *pageId) {
	DbgPrintln(F("SSEKeepAlive: "));
	Subscription *subscription = _subscription;
	while (subscription) {
		AsyncWebServerRequest &request = subscription->request;
		DbgPrintln(F(" - client IP: "), IPAddress(subscription->clientIP).toString());
		if (request.client()->connected()) {
			AsyncResponseStream *response = request.beginResponseStream(PSTR("text/event-stream"));
			serverSentEventHeader(*response); // add headers
			DbgPrintln(F(" - after header "));
			response->write(PSTR("event: event\n"));  // this name could be anything, really.
			response->printf_P(PSTR("data: { \"TYPE\":\"ALIVE\",\"sitemapName\":\"%s\",\"pageId\":\"%s\"}\n"), sitemap, pageId);
			request.send(response);
			//response->write(sitemap);
			//response->write(PSTR("\",\"pageId\":\""));
			//response->write(pageId);
			//response->write(PSTR("\"}\n"));
			//client->flush();
		} //else client->stop();
		subscription = subscription->next;	}
}
*/
/* 
AsyncResponseStream *response = request->beginResponseStream("application/json");
DynamicJsonBuffer jsonBuffer;
JsonObject &root = jsonBuffer.createObject();
root["heap"] = ESP.getFreeHeap();
root["ssid"] = WiFi.SSID();
root.printTo(*response);
request->send(response);
*/
/*
void OpenHab::SSEPageUpdate(JsonVariant obj) {
	DbgPrintln(F("serverSentEvent: "));
	Subscription *subscription = _subscription;
	while (subscription) {
		AsyncWebServerRequest &request = subscription->request;
		DbgPrintln(F(" - client IP: "), IPAddress(subscription->clientIP).toString());
		if (request.client()->connected()) { //status() == WS_CONNECTED) {
			AsyncResponseStream *response = request.beginResponseStream(PSTR("text/event-stream"));
			serverSentEventHeader(*response);
			//DbgPrintln(F(" - after header "));
			response->write(PSTR("event: event\ndata: "));	// this name could be anything, really.
			serializeJson(obj, *response);
			request.send(response);
		//client->flush();
		} else request.client()->close(); //client->stop();
		subscription = subscription->next;
	}
}
*/
/* 
void OpenHab::handleSSEdata(WiFiClient client) {
  if (client) {
    serverSentEventHeader(client);
    while (client.connected()) {
      serverSentEvent(client);
      delay(16); // round about 60 messages per second
    }

    // give the web browser time to receive the data
    delay(1);
    // close the connection:
    client.stop();
    Serial.println("client disconnected");
  }
}
*/
const char *OpenHab::functionOR(Group *group, int *numItems) {
	int count = 0;
	ItemList *itemList = group->itemList;
	DbgPrintln(F("functionOR"));
	JsonObject f = group->item->obj[F("function")];
	JsonArray fparams = f[F("params")];
	const char *fvalue = fparams[0];
	//DbgPrintln(F("- value: "), fvalue);
	while (itemList) {
		DbgPrint(F("while itemlist: "), itemList->item->name);		
		DbgPrintln(F(" - "), itemList->item->state);		
		if (strcmp(fvalue, itemList->item->state) == 0) count++;
		itemList = itemList->next;
	}
	DbgPrintln(F("functionOR - count: "), count);
	//DbgPrintf("functionOR - state address: %p\n", (void *)fvalue);
	*numItems = count;
	return (char *)(count > 0) ? fvalue : fparams[1].as<const char *>();
}

float OpenHab::functionAVG(ItemList *itemList) {
	DbgPrintln(F("functionAVG"));
	float avg = 0;
	int count = 0;
	while (itemList) {
		count++;
		avg += strtof(itemList->item->state, nullptr);
		itemList = itemList->next;
	}
	return (count) ? avg / count : 0;
}

FORCE_INLINE OpenHab::Group *OpenHab::getGroup(const char *name) {
	Group *group = _groupList;
	while (group && (strcmp(group->name, name)))
		group = group->next;
	return group;
} 

OpenHab::Item *OpenHab::getItem(const char *name) {
	Item *item = _itemList;
	while (item) {
		if (strcmp(item->name, name) == 0) return item;
		item = item->next;
	}
	return nullptr;
}

// type == ItemNone: we just have a group name and item is a group member
// type == ItemGroup: we have a true group, check groupType for a group with dynamic label & state 
OpenHab::Group *OpenHab::newGroup(const char *groupName, Item *item, ItemType type) {
	GroupFunction groupFunction = FunctionNone;
	JsonObject obj = item->obj;
	JsonVariant groupTypeVariant = obj[F("groupType")];  
	ItemType groupType = (groupTypeVariant.isNull()) ? ItemUnknown : getItemType(groupTypeVariant);
	DbgPrint(F("adding group with name: "), groupName);
	DbgPrintln(F(" - grouptype: "), groupType);
	
	if (type == ItemGroup) { // item refers to a true group item
		JsonObject groupFunctionObj = obj[F("function")];  // if it has a function, it has a dynamic label & state
		if (!groupFunctionObj.isNull()) {
			const char *groupFunctionStr = groupFunctionObj[F("name")];
			if (!strcmp_P(groupFunctionStr, PSTR("AVG")))
				groupFunction = FunctionAVG;
			else if (!strcmp_P(groupFunctionStr, PSTR("OR"))) groupFunction = FunctionOR;
		}
		DbgPrintln(F(" - groupfunction: "), groupFunction);
	}		

	if (Group *group = getGroup(groupName)) { // we might have a group with just a name
		if (groupType != ItemUnknown) { // group with dynamic label/state found
			DbgPrintln(F("Group leader found: "), groupName);
			group->groupType = type; // update type		
			group->groupFunction = groupFunction; // update function
			group->item = item;
		}
		if (type != ItemGroup) // we are adding an item to an exising group
			group->itemList = new ItemList{item, group->itemList};
		return group;
	}
	DbgPrintln(F(" - insert new group in list: "), groupName);
	return _groupList = new Group {groupName, item, groupType, groupFunction,
		(type == ItemUnknown) ? new ItemList{item, nullptr} : nullptr, _groupList};
}
FORCE_INLINE OpenHab::Group *OpenHab::addItemToGroup(const char *groupName, Item *item) {
	DbgPrint(F("addItemToGroup adding item named: "), item->name);
	DbgPrintln(F(" - to group: "), groupName);
	return newGroup(groupName, item, ItemUnknown); // create or get group
}

FORCE_INLINE static size_t snprintftime(char *state, char *label, const char *labelFormat, int count = 0) {
	static char _timeDateBuf[40];
	static tm tmb;
	strptime(state, "%Y-%m-%dT%H:%M:%S", &tmb);
	//DbgPrint(F(" - format: "), labelFormat);
	return (count == 0) ? strftime(_timeDateBuf, 40, labelFormat, &tmb) : strftime(label, count, labelFormat, &tmb);
}		
FORCE_INLINE static size_t snprintftime(float state, char *label, const char *labelFormat, int count = 0) { return 0; }
FORCE_INLINE static size_t snprintftime(int state, char *label, const char *labelFormat, int count = 0) { return 0; }

template <typename T> static void sprf(T state, OpenHab::Item *item) {
	//static char _oldLabel[128];
	JsonVariant labelObj = item->widgetObj[F("label")];
	const char *labelFormat = item->label; // formatted label
	char *label = (char *)(labelObj.as<const char *>());  //pointer to last formatted label or nullptr initially
	//size_t len = (label) ? strlen(label) : 0;
	//if (len) strncpy(_oldLabel, label, len); 
	//_oldLabel[len] = 0; // save a copy of old label, assuming < 128 characters
	DbgPrint(F("sprf oldLabel: "), label);
	DbgPrint(F(" - state: "), state);
	size_t count = (item->type == ItemDateTime) ? snprintftime(state, label, labelFormat) : snprintf(NULL, 0, labelFormat, state);
	DbgPrint(F(" - count: "), count);
	label = (char *) realloc((void *)label, ++count);
	(item->type == ItemDateTime) ? snprintftime(state, label, labelFormat, count) : sprintf(label, labelFormat, state);
	labelObj.set((const char *)label); // write back pointer to updated label
	OpenHab::ItemReference *referenceList = item->referenceList;
	while (referenceList) {
		labelObj = referenceList->widgetObj[F("label")];
		labelObj.set((const char *)label);
		referenceList = referenceList->next; 
	}
	DbgPrintln(F(" - newLabel: "), label);
}

void OpenHab::updateLabel(Item *item, int numItems) {
	DbgPrint(F("updateLabel"));
	// auto sprf = [&](auto f) { count = snprintf(NULL, 0, pattern, f) + 1; label = (char *) realloc((void *)label, count); sprintf(label, pattern, f); }	
	ItemType type = item->type;
	DbgPrintln(F(" - type: "), ItemTypeStr[type]);
	//if (type == ItemGroup) type = 

	switch (type) {
		case ItemContact:
		case ItemString:
		case ItemSwitch:
		case ItemDateTime:
			sprf(item->state, item); break;
		case ItemNumber:
			sprf(strtof(item->state, NULL), item); break; // (float)atof(item->state)
		case ItemGroup:
		case ItemDimmer:
			(numItems == -1) ? sprf(atoi(item->state), item) : sprf(numItems, item); break;
		default:;
	}
}

FORCE_INLINE void OpenHab::setGroupState(const char *groupName) {
	DbgPrintln(F("setState group:"), groupName);
	Group *group = getGroup(groupName);
	if (group->groupFunction == FunctionAVG) {
		DbgPrintln(F("updateLabel group: FunctionAVG"));
		setState(group->item, functionAVG(group->itemList), false);
		updateLabel(group->item);
	} else if (group->groupFunction == FunctionOR) {
		DbgPrintln(F("updateLabel group: FunctionOR"));
		int count;
		setState(group->item, functionOR(group, &count), false);
		updateLabel(group->item, count);
	}
}

// Function to set and eventually propagate (e.g. label, group state) the state of an item 
void OpenHab::setState(Item *item, const char *state, bool updateGroup) {
	DbgPrint(F("setState: "), state);
	//DbgPrint(F(" - old state: "), item->state);
	static char oldState[64];
	size_t len = (item->state) ? strlen(item->state) + 1 : 0;  // Length of old state
	if (len) strncpy(oldState, item->state, min(len, (size_t)127));
	DbgPrint(F(" - old state: "), oldState);
	bool isCurrentDateTime = ((item->type == ItemDateTime) && !strncmp_P(item->name, PSTR("CurrentDate"), 12)); // item reflecting current Date/Time?
	len = (isCurrentDateTime) ? 24 : strlen(state) + 1;
	void *p = realloc((void *) item->state, len);  // New state might require more space
	if (isCurrentDateTime) { // This is a request to supply the current date and time
		time_t now = time(nullptr); // Time since epoch
    	const tm* tm = localtime(&now); // Converted to localtime
		printTm(F(" - currentDataTime: "), tm);
		strftime ((char *) p, 24 ,"%FT%T", tm);  // Converted to an ISO date string
		//DbgPrint(F("currentDataTime: "), (const char *)p);
		auto setStateBind = std::bind(static_cast<void(OpenHab::*)(OpenHab::Item*, const char*, bool)>(&OpenHab::setState), this, item, state, true);
		_currentDateTimer.attach(60.0, setStateBind);  // Refresh time every minute (could be optimized in the future)
	} else memcpy(p, state, len);  // Replicate the new state
	DbgPrintln(F(" new state: "), (char *) p);
	item->state = (char *)p;
	item->obj[F("state")] = (const char *) p;
	ItemReference *referenceList = item->referenceList;
		while (referenceList) {
		referenceList->obj[F("state")] = (const char *) p;
		referenceList = referenceList->next; 
	}
	DbgPrintln(F(" - updateGroup: "), (updateGroup) ? "true" : "false");
	//if (isCurrentDateTime) SSEPageUpdate(item->widgetObj);
	if (!updateGroup) return;

	if (item->type == ItemGroup) {
		Group *group = getGroup(item->name);
		ItemList *itemList = group->itemList;
		while (itemList) {
			//DbgPrintln(" - before setState: ", itemList->item->name);
			//DbgPrintln(" - before setState: ", state);
			setState(itemList->item, state, false);
			itemList = itemList->next;
		}
	} else {  // if item is part of a (number of) group(s), update their states accordingly
		JsonArray groupNames = item->obj[F("groupNames")];
		for (JsonVariant groupName : groupNames)
			setGroupState(groupName);
	}
	if (item->label) updateLabel(item);  // finally update the parent label reflecting the new state
	DbgPrintln(F(" - exit setState"));
}

// Function to set and eventually propagate (e.g. label, group state) the state of an item with numeric state (e.g. type Number)
void OpenHab::setState(Item *item, float f, uint8 precision, bool updateGroup) {
    char fs[14];  // Used to convert float to string
	DbgPrintln(F("setState float: "), f);
	setState(item, dtostrf(f, precision + 2, precision, fs), updateGroup);
}

FORCE_INLINE bool isFormatted(const char* label) {
	char curr, next = *label++;
	while ((curr = next) != '\0') {
		next = *label++;
		if ((curr == '%') && (next != '%')) return true;
	}
	return false;
}

// Adds an Item to the itemList and set its initial state as well as any label deduced from that state
// If the item is a group, add the group
// If the itme is member of a group, add the group when not yet existing and include the item as member of the group
FORCE_INLINE void OpenHab::newItem(JsonVariant itemObj, JsonVariant widgetObj, Sitemap *sitemap) {
	const char *name = itemObj[F("name")];
	const char *label = widgetObj[F("label")];
	ItemType itemType = getItemType(itemObj[F("type")]);
	const char *state = itemObj[F("state")];
	//DbgPrint(F("Item: name: "), name); DbgPrint(F(" - type: "), itemType);
	//DbgPrint(F(" - state: "), state); DbgPrint(F(" - label: "), label);
	//DbgPrintln(F(" - sitemap: "), sitemap->obj[F("id")].as<const char *>());

	bool labelIsFormatted = isFormatted(label); //itemObj.containsKey(F("stateDescription"));
	//DbgPrintln(F("label containskey: "), labelIsFormatted);
	//DbgPrintln(F("label isFormatted: "), isFormatted(label));
	if (labelIsFormatted && (itemType == ItemDateTime))
		convDateTimeJavaToC((char *) label); // convert Java label format to C/C++ strftime format
	JsonObject stateObj = itemObj[F("stateDescription")];
	if (stateObj) {
		JsonArray options = stateObj[F("options")];
		if (options.size() > 0) {
			for (JsonVariant option : options)
				if (!strcmp(option[F("value")], state))
					state = option[F("label")];
			//DbgPrintln(F("options state: "), state);
		}
	}
	Item *item = getItem(name);
	if (item) {
		item->referenceList = new ItemReference { itemObj, widgetObj, item->referenceList };
		setState(item, state);
		return;
	}
	// At this point we have a new item
	_itemList = item = new Item{name, itemObj[F("link")], nullptr, (labelIsFormatted) ? label : nullptr, itemObj, widgetObj, nullptr, sitemap, _itemList, itemType};
	
	if (labelIsFormatted) widgetObj[F("label")] = nullptr;
	DbgPrint(F("item: "), item->name); DbgPrintln(F(", "), state); 

	if (itemType == ItemGroup) // We have a group
		newGroup(name, item, ItemGroup);  // ItemNone -> group has no dynamic label

	JsonArray groupNames = itemObj[F("groupNames")];
	if (groupNames.size() > 0)
		for (JsonVariant groupName : groupNames)
			addItemToGroup(groupName, item);
	setState(item, state);
	//DbgPrintln(" - back from setState");
}

void OpenHab::registerLinkHandlers(const JsonVariant prototype, TopLevelSitemap *sitemap) {
	if (prototype.is<JsonObject>()) {
		const JsonObject& obj = prototype;
		for (const JsonPair pair : obj) {
			const char *key = pair.key().c_str();
			if (!strcmp_P(key, PSTR("link"))) { // Sitemap
				const char* link = pair.value().as<char*>();
				if (!strncmp_P(&link[6], PSTR("site"), 4)) {
					DbgPrintln(F("sitemap: "), link);
					sitemap->sitemapList = new Sitemap{link, (JsonVariant) obj, sitemap->sitemapList};
          			//_server.on(STRREF(link), std::bind(&OpenHab::handleSitemap, this, (JsonVariant) obj));
				}
			} else if (!strcmp_P(key, PSTR("item"))) // Items
				newItem(pair.value().as<JsonObject>(), obj, sitemap->sitemapList);
    		
			registerLinkHandlers(pair.value().as<JsonObject>(), sitemap); //, pair.key);
			for (auto arr : pair.value().as<JsonArray>()) {
				registerLinkHandlers(arr.as<JsonVariant>(), sitemap); //, pair.key);
			}
		}
	} else if (prototype.is<JsonArray>()) {
		const JsonArray& arr = prototype;
		for (const auto& elem : arr) registerLinkHandlers(elem.as<JsonVariant>(), sitemap); //, parent);
	}
}

//DynamicJsonDocument OpenHab::getJsonDocFromFile(const char *fileName) {
DynamicJsonDocument OpenHab::getJsonDocFromFile(String fileName) {
	DbgPrintln(F("OpenHab::getJsonDocFromFile: file name: "), fileName);
	File f = SPIFFS.open(fileName, "r");
	//DbgPrintln(F("getJsonDocFromFile: file name: "), fileName);
	/*if (!f) {
		DbgPrintln(F("open file failed"));
		return DynamicJsonDocument(0);
	} */
	DynamicJsonDocument doc(ESP.getFreeHeap() - 4096);
	//DynamicJsonDocument doc(ESP.getFreeHeap() - 2048);
	DeserializationError err = deserializeJson(doc, f, DeserializationOption::NestingLimit(20));
	f.close();
	//DbgPrintln(F("DynamicJsonDocument: "), doc.capacity());
	//DbgPrintln(F(" - deserializeJson: "), measureJson(doc));
	if (err == DeserializationError::Ok) doc.shrinkToFit();
	else DbgPrintln(F("deserializeJson failed"), err.c_str());
	//DbgPrintln(F(" - deserializeJson: "), measureJson(doc));
	//DbgPrintln(F("free heap memory @exit: "), ESP.getFreeHeap());
	return doc;
}

OpenHab::TopLevelSitemap *OpenHab::GetSitemapsFromFS() {
	DbgPrintln(F("OpenHab::GetSitemapsFromFS"));
	TopLevelSitemap *topLevelSitemapList = nullptr;
	DbgPrintln(F("free heap memory: "), ESP.getFreeHeap());
	Dir dir = SPIFFS.openDir(F("/conf/sitemaps"));
	while (dir.next()) {
		//File f = dir.openFile("r");
		//DbgPrintln(F("GetSitemapsFromFS: "), fileName);
		String fileName = dir.fileName();
		//const char* fileName = dir.fileName().c_str();
		//TopLevelSitemap *sitemap = new TopLevelSitemap{strdup(fileName.c_str()), getJsonDocFromFile(fileName.c_str()), nullptr }; //, topLevelSitemapList 
		TopLevelSitemap *sitemap = new TopLevelSitemap{fileName, getJsonDocFromFile(fileName), nullptr }; //, topLevelSitemapList 
		if (sitemap->jsonDoc.isNull()) {
			//DbgPrintln(F("jsonDoc is null"), sitemap->jsonDoc.memoryUsage());
			delete sitemap;
			continue;
		}
		//DbgPrint(F("toplevelsitemap created: "), sitemap->jsonDoc.memoryUsage());
		//DbgPrintln(F(" - with name: "), sitemap->name);
		registerLinkHandlers(sitemap->jsonDoc.as<JsonObject>(), sitemap);
		topLevelSitemapList = sitemap;
		break; //At this moment, allow only one sitemap
	}
	DbgPrintln(F("free heap memory @exit: "), ESP.getFreeHeap());
	return topLevelSitemapList;
}

bool OpenHab::Init(const char *ssid, const char *APssid, const char* passphrase, const char*allowedMAC[], const char *local_ip, const char *gateway, const char *subnet) {
 	DbgPrintln(F("OpenHab::InitServer"));
	IPAddress espIP;
	// Setup WiFi network
 	WiFi.persistent(false);	// Disables storing the SSID and pasword by SDK
	WiFi.setSleepMode(WIFI_LIGHT_SLEEP); //WIFI_NONE_SLEEP);
	WiFi.setOutputPower(17);        // 10dBm == 10mW, 14dBm = 25mW, 17dBm = 50mW, 20dBm = 100mW
	WiFi.setAutoConnect(false);	// Disables the auto connect of the SDK
  	WiFi.softAPdisconnect(true);
	WiFi.enableAP(false);
  	WiFi.mode(WIFI_STA);
	WiFi.disconnect();
	delay(1000); 
 
	/*// Don't save WiFi configuration in flash - optional
	  int32_t  channel (void)
	  WiFiSleepType_t  getSleepMode ()
	  bool  setPhyMode (WiFiPhyMode_t mode)
	  WiFiPhyMode_t  getPhyMode ()
	  void  setOutputPower (float dBm)
	  WiFiMode_t  getMode ()
	  bool  forceSleepBegin (uint32 sleepUs = 0)
	  bool  forceSleepWake ()
	  int  hostByName (const char *aHostname, IPAddress & aResult)

	DbgPrintln("Scan start ... ");
  	int n = WiFi.scanNetworks();
  	DbgPrintln("network(s) found: ", n);
  	for (int i = 0; i < n; i++) DbgPrintln("-- ", WiFi.SSID(i));
	*/	
	int len = strlen(passphrase);
	char *_passphrase = strdup(passphrase);
	for (int i = 0, j = 1; i < len; i += 2, j += 2) {
		std::swap(_passphrase[i], _passphrase[j]);
	}
	char *pwdDecoded = (char *)calloc(len + 1, sizeof(char));
	base64_decode_chars(_passphrase, len - 1, pwdDecoded);
	delete _passphrase;
	DbgPrintln(F("passcode: "), pwdDecoded);

	if (ssid) { // We have an SSID, connect to this AP
		if (!WiFi.enableSTA(true)) { //enable STA failed
			DbgPrintln(F("could not enable station mode"));
		} else { 
			wifi_station_set_hostname(APssid);
			WiFi.begin(ssid, pwdDecoded);
			//while (WiFi.status() != WL_CONNECTED) delay(500);
			if (WiFi.waitForConnectResult() == WL_CONNECTED) {
				DbgPrint(F("Connected to AP "), ssid);
				DbgPrint(F(" with MAC:"), WiFi.macAddress());
				DbgPrintln(F("and name:"), WiFi.hostname());
				_espIP = WiFi.localIP();
				//configTime(TZ_Europe_Brussels, "0.be.pool.ntp.org", "1.be.pool.ntp.org"); // If on AP, get time
				configTime(TZ_Etc_GMTm7, "pool.ntp.org"); // If on AP, get time
				int count = 100;
				while((time(nullptr) <= 100000) && count--) delay(100);
				if (count < 0) Serial.println(PSTR("Time server not reachable"));
				else Serial.println(F("Time from time server"));
				goto out;
			}
		}
	}
	// Fallback to SoftAP if no connection to AP
	DbgPrintln(F("Falling back to soft AP due to failed connection to AP "), ssid);
  	WiFi.mode(WIFI_AP);
  	WiFi.enableSTA(false);
	WiFi.disconnect(true);
	if (APssid) { // We  stat
		if (!WiFi.enableAP(true)) { //enabling of Soft AP failed
			DbgPrintln(F("could not create Access Point"));
			return false;
		}
		IPAddress local_IP(192,168,4,1);
    	IPAddress gateway(192,168,4,1);
    	IPAddress subnet(255,255,255,0);

		wifi_station_set_hostname(APssid);
		if (!WiFi.softAPConfig(local_IP, gateway, subnet))
		DbgPrintln(F("could not configure Access Point"));
		WiFi.softAP(APssid, pwdDecoded, 13, false, 4);
    	MDNS.begin(APssid);
		wifi_station_set_hostname(APssid);
    	WiFi.hostname(APssid);
		DbgPrintln(F("Soft AP name"), WiFi.hostname());
		if (local_ip) //Set local AP IP
			WiFi.softAPConfig(local_IP, gateway, subnet);
		_espIP = WiFi.softAPIP();
	}
out:
	delete pwdDecoded;
	DbgPrintln(F("IP address: "), _espIP.toString());
	//_currentDateTimer.attach(60.0, std::bind(&OpenHab::updateTime, this));
	delay(100);
	SPIFFS.begin();
	wifi_set_event_handler_cb(wifiEventHandler);
	DbgPrintln(F("Exit OpenHab::InitServer"));
	return true;
}

// Start the web server, handle all requests in a single function to save memory

void OpenHab::StartServer() { //
	//_server.on(FPSTRREF("/rest/items"), std::bind(&OpenHab::handleItems, this));
	//_server.on(F("/rest/sitemaps/events/subscribe"), std::bind(&OpenHab::handleSubscribe, this));
	//_server.on(FPSTRREF("/rest/services"), [this]() { SendFile(F("/conf/services.cfg")); });  //std::bind(&OpenHab::handleServices, this))
	//_server.on(FPSTRREF("/rest"), [this]() { SendFile(F("/conf/rest")); });  //std::bind(&OpenHab::handleServices, this))
	//_server.on(F("/icon"), [this]() { SendFile(_server.uri() + getContentTypeExt(IMAGE_PNG), true, IMAGE_PNG); }, false);
	_topLevelSitemapList = GetSitemapsFromFS();
	//_server.on(FPSTRREF("/rest/sitemaps"), std::bind(&OpenHab::handleSitemaps, this, _sitemapList));
	_server.onNotFound(std::bind(&OpenHab::handleAll, this, std::placeholders::_1));
	_server.begin();
}

void OpenHab::SendJson(AsyncWebServerRequest &request, JsonVariant obj) {
	AsyncJsonResponse *response = new AsyncJsonResponse(obj, getContentTypeStr(APP_JSON));
	request.send(response);
 	DbgPrintln(F("SendJson - free heap memory: "), ESP.getFreeHeap());
}

//void OpenHab::SubscriptionSendEvent(Item *item) {}

/*void OpenHab::HandleClient() {
	_server.handleClient();
}


void OpenHab::SendFile(AsyncWebServerRequest &request, String fname, const bool isChunked, ContentType contentType) {
	DbgPrintln(F("OpenHab::SendFile "), fname);
	//AsyncResponseStream *response = request.beginResponseStream(getContentTypeStr(APP_JSON));
	char buf[256];
	if (SPIFFS.exists(fname)) {
		File f = SPIFFS.open(fname, "r");
		int sz = f.size();
		while (sz > 0) {
			size_t len = std::min((int)(sizeof(buf) - 1), sz);
			f.readBytes(buf, len);
			buf[len] = '\0';
			response->write((const char*)buf);
			sz -= len; 
		}
		f.close();
	} else DbgPrintln(F("File not found"));
}
*/
void OpenHab::handleSitemap(AsyncWebServerRequest &request, const char *uri) {
	static int handleCount = 0;
	if (strcmp_P(uri, PSTR("events/subscribe")) == 0)
		return handleSubscribe(request);	//this is a sitemap event registration
	if (strncmp_P(uri, PSTR("events/"), 7) == 0)
		return SSEEventHandler(request);	//this is a sitemap event registration
	if ((handleCount < 10) || ((handleCount % 100) == 99)) {
		DbgPrintln(F("OpenHab::handleSitemap - "), uri);
		//DbgPrintln(F("method: "), HTTPMethodStr[request.method()]);
	}
	TopLevelSitemap *topLevelSitemap = _topLevelSitemapList;
	//while (topLevelSitemap) {
		Sitemap *sitemap = topLevelSitemap->sitemapList;
		while (sitemap) {
			//DbgPrintln(F("sitemap link: "), sitemap->link);
			if (strcmp(sitemap->link +15, uri) == 0)
				return SendJson(request, sitemap->obj);
			sitemap = sitemap->next;
		}
	//	topLevelSitemap = topLevelSitemap->next;
	//}
	handleNotFound(request, uri); 
}

void OpenHab::handleItem(AsyncWebServerRequest &request, const char *uri) {
	DbgPrintln(F("OpenHab::handleItem"));
	Item *item = _itemList;
	while (item) {
		//DbgPrintln(F(" - Item name: "), item->name);
		if (strcmp(item->name, uri) == 0) {
			JsonVariant obj = item->obj;
			DbgPrintln(F("Item found - free heap memory: "), ESP.getFreeHeap());
			//DbgPrintln(F("Server method: "), _server.method());
			//if ((handleCount < 10) || ((handleCount % 100) == 99)) {
			//DbgPrintRequest(request, F("OpenHab::handleItem - "));
			//DbgPrintln("OpenHab::handleItem - type: ", ItemTypeStr[item.type]);
			//DbgPrintln("OpenHab::handleItem - state: ", item.state);
			//}
			if (request.method() == HTTP_GET) return SendJson(request, obj);
			else if (request.method() == HTTP_POST) {
				DbgPrintRequest(request, "handleItem - POST request: ");
				if (request.hasArg(F("plain"))) { //Check if body received as plain argument
					//if (!strcmp(objType, "Switch"))
					const char *state = request.arg(F("plain")).c_str();
					if (strcmp(state, item->state)) { // state (type char *) has changed 
						setState(item, state);				
						DbgPrintln(F("new state: "), item->state);
					}
					DbgPrintln(F("free heap memory: "), ESP.getFreeHeap());
				}
				request.send_P(200, getContentTypeStr(TEXT_PLAIN), NULL);
				//request.send_P(200, PSTR("text/plain"), NULL);
			}
			DbgPrintln(F("free heap memory @exit: "), ESP.getFreeHeap());
			return;  // item found and handled
		}
		item = item->next;
	};
	handleNotFound(request, uri);
}

void OpenHab::handleSitemaps(AsyncWebServerRequest &request, TopLevelSitemap *sitemap) {
	DbgPrintln(F("OpenHab::handleSiteMaps"));
	//AsyncResponseStream *response = request.beginResponseStream(getContentTypeStr(APP_JSON));
	AsyncWebServerResponse *response = request.beginChunkedResponse(getContentTypeStr(APP_JSON), [&](uint8_t *buffer, size_t maxLen, size_t index) -> size_t {
  		//Write up to "maxLen" bytes into "buffer" and return the amount written.
  		//index equals the amount of bytes that have been already sent
  		//You will be asked for more data until 0 is returned
  		//Keep in mind that you can not delay or yield waiting for more data!
		static size_t fsz = 0;
		static File f;
		static bool done = false;
		size_t len = 0;

		if (index == 0) { // first iteration, initialize
			//DbgPrintln(F("index == 0 "), maxLen);
			done = false;
			if (SPIFFS.exists(_topLevelSitemapList->name)) {
				f = SPIFFS.open(_topLevelSitemapList->name, "r");
				fsz = f.size();
				*buffer++ = '[';
				maxLen--;
			} else DbgPrintln(F("File not found"));
		}
		if (fsz > 0) { // Keep writing from file until complete
			len = std::min(maxLen, fsz);
			fsz -= len = f.readBytes((char *)buffer, len);
			//DbgPrint(F("chunkedresponse - fsz: "), fsz);
			//DbgPrint(F(" - len: "), len);
			//DbgPrintln(F(" - done: "), done);
		}
		if (done) return 0;	// We are done
		if ((fsz == 0) && (len < --maxLen))  { // File is written, write final bracket if there is still room
			//DbgPrintln(F("fsz == 0 "), maxLen);
			*(buffer + len++) = ']';
			done = true;
		}
		//DbgPrintln(F(" - returning len: "), len);
		return len;
	});
	request.send(response);
}

ICACHE_FLASH_ATTR void OpenHab::handleSubscribe(AsyncWebServerRequest &request) {
	DbgPrintln(F("OpenHab::handleSubscribe"));
	//DbgPrintRequest(request, F("subscribe: "));
	//File f = SPIFFS.open(F("/conf/subscribe"), "r");
	DynamicJsonDocument	jsonDoc = getJsonDocFromFile(PSTR("/conf/subscribe"));
	AsyncClient* client = request.client();
	IPAddress clientIP;
	if (client) clientIP = client->remoteIP();  
	DbgPrintln(F(" - clientIP: "), clientIP.toString());
	String SSEurl = F("http://");
	SSEurl += _espIP.toString();
	SSEurl += F(":");
	SSEurl += _port;
	size_t offset = SSEurl.length();
	SSEurl += F("/rest/sitemaps/events/");
	//SSEurl += F("events/");
	DbgPrintln(F(" - SSEurl: "), SSEurl);

	Subscription *subscription = _subscription;
	while (subscription && (subscription->clientIP != (uint32_t) clientIP))
		subscription = subscription->next;
	if (!subscription) {
		Serial.printf_P(PSTR("new client IP %x %s\n"), (uint32_t) clientIP, clientIP.toString().c_str());	
		uint8_t uuid[16];
		ESP8266TrueRandom.uuid(uuid);
		String uuidString = ESP8266TrueRandom.uuidToString(uuid);
		SSEurl += uuidString;
//		subscription = new Subscription{(uint32_t) clientIP, request, _subscription, AsyncEventSource(SSEurl), strdup(uuidString.c_str())};
		subscription = new Subscription{(uint32_t) clientIP,  AsyncEventSource(SSEurl), _subscription, strdup(uuidString.c_str())};
		DbgPrintln(F(" - past new subscription: "), SSEurl.c_str() + offset);
		_server.addHandler(&subscription->events);
		//_server.on(SSEurl.c_str() + offset, std::bind(&OpenHab::SSEEventHandler, this, request));
		DbgPrintln(F(" - past server.on: "), SSEurl);
		subscription->events.onConnect([&](AsyncEventSourceClient *client) {
    		DbgPrintln(F("onConnect"));
			if(client->lastId())
      			Serial.printf("Client reconnected! Last message ID that it gat is: %u\n", client->lastId());
    		//send event with message "hello!", id current millis
    		// and set reconnect delay to 1 second
    		//client->send("hello!",NULL,millis(),1000);
 		});
		_server.addHandler(&subscription->events);
		//memcpy((void *) subscription->uuidStr, (const void *)uuidString.c_str(), 37);
		DbgPrintln(F(" - past addHandler"));
		_subscription = subscription;
	} else {
		//subscription->request = request; //update request
		SSEurl += subscription->uuidStr;
	}
	//memcpy((void *)(uuidStr + sizeof("/rest/sitemaps/events")), subscription->uuidStr, 36); //patch UUID
	DbgPrintln("Server Sent Event location: ", SSEurl);
	JsonObject context = jsonDoc.as<JsonObject>()[F("context")];
	JsonArray location = context[F("headers")][F("Location")];
	location[0] = (const char *)(SSEurl.c_str());
	//size_t len = measureJson(jsonDoc);
	//char* jsonStr = new char[len];
	//serializeJson(jsonDoc, jsonStr, len);
	SendJson(request, jsonDoc.as<JsonVariant>());
	//subscription->events.send(jsonStr, "event"); //, millis());
	//delete jsonStr;
	jsonDoc.clear();
	DbgPrintln(F("free heap memory @exit: "), ESP.getFreeHeap());
}

ICACHE_FLASH_ATTR void OpenHab::handleNotFound(AsyncWebServerRequest &request, const char* uri) {
	DbgPrintln(F("OpenHab::handleNotFound: "), uri); // At this point we don't understand the request
	DbgPrintRequest(request, F("handleNotFound"));
	request.send(404, F("text/plain"), F("Not Found")); //request.responseCodeToString(404));
}

// ESP webserver does not support wildcards, process image/icon requests here
void OpenHab::handleAll(AsyncWebServerRequest *request) {
	const char* uri = request->url().c_str();
	DbgPrintln(F("OpenHab::handleAll: "), uri);
	DbgPrintln(F("free heap memory @entry: "), ESP.getFreeHeap());
	if (!strncmp_P(uri, PSTR("/icon/"), 6) || !strcmp_P(uri, PSTR("/chart")))
//		return SendFile(strcat_P((char *)uri, getContentTypeExt(IMAGE_PNG)), true, IMAGE_PNG);
//		return SendFile(*request, strcat_P((char *)uri, getContentTypeExt(IMAGE_SVG)), true, IMAGE_SVG);
		return request->send(SPIFFS, strcat_P((char *)uri, getContentTypeExt(IMAGE_SVG)), getContentTypeStr(IMAGE_SVG));
	if (strncmp_P(uri, PSTR("/rest/items/"), 12) == 0)
	//if (uri.startsWith(F("/rest/items/")))
		return handleItem(*request, uri + 12);
	if (strncmp_P(uri, PSTR("/rest/sitemaps/"), 15) == 0)
		return (handleSitemap(*request, uri + 15));
	if (strcmp_P(uri, PSTR("/rest/sitemaps")) == 0)
		return handleSitemaps(*request, _topLevelSitemapList);
	//if (strcmp_P(uri, PSTR("/chart")) == 0)
		//return SendFile(*request, strcat_P((char *)uri, getContentTypeExt(IMAGE_PNG)), true, IMAGE_PNG);
		//return request.send(SPIFFS, strcat_P((char *)uri, getContentTypeExt(IMAGE_SVG)), getContentTypeStr(IMAGE_SVG));
	if (strcmp_P(uri, PSTR("/rest")) == 0)
		//return SendFile(*request, F("/conf/rest"));
		return request->send(SPIFFS, F("/conf/rest"), getContentTypeStr(APP_JSON));
	if ((strcmp_P(uri, PSTR("/rest/links")) == 0) || (strcmp_P(uri, PSTR("/rest/bindings")) == 0))
		return request->send_P(200, PSTR("application/json"), PSTR("[]"));
	if (strcmp_P(uri, PSTR("/rest/services")) == 0)
		//return SendFile(*request, F("/conf/services.cfg"));
		return request->send(SPIFFS, F("/conf/services.cfg"), getContentTypeStr(APP_JSON));
	handleNotFound(*request, uri);
}