// Copyright Ewald Comhaire 2016-2017
// MIT License
//
// Arduino Micro OpenHAB2.0 library
// If you like this project, please add a star!
#ifndef OpenHABInclude
#define OpenHABInclude
#pragma once
#ifndef OpenHABDebug
#define OpenHABDebug
#endif

/* #define DEBUG_ESP_OOM
#define UMM_INTEGRITY_CHECK
#define UMM_POISON
#define DBG_LOG_LEVEL 6
*/
// Avoid warning: always_inline function might not be inlinable [-Wattributes]
#ifdef _MSC_VER  // Visual Studio

#define FORCE_INLINE  // __forceinline causes C4714 when returning std::string
#define NO_INLINE __declspec(noinline)
#define DEPRECATED(msg) __declspec(deprecated(msg))

#elif defined(__GNUC__)  // GCC or Clang

#define FORCE_INLINE __attribute__((always_inline))
#define NO_INLINE __attribute__((noinline))
#pragma GCC diagnostic ignored "-Wattributes"
#if __GNUC__ > 4 || (__GNUC__ == 4 && __GNUC_MINOR__ >= 5)
#define DEPRECATED(msg) __attribute__((deprecated(msg)))
#else
#define DEPRECATED(msg) __attribute__((deprecated))
#endif

#else  // Other compilers

#define FORCE_INLINE
#define NO_INLINE
#define DEPRECATED(msg)

#endif

extern "C" {
#include "c_types.h"
}

#include <ESP8266WiFi.h>
#include <WiFiClient.h>
#include <time.h>
#include <sys/time.h>
#include <coredecls.h>
#include <ESPAsyncWebserver.h>
#include <ESP8266mDNS.h>
#include "ESP8266TrueRandom.h"
#include <ESP8266WiFiType.h>
#include <ESP8266WiFiSTA.h>
#include <ESP8266WiFiScan.h>
#include <ESP8266WiFiMulti.h>
#include <ESP8266WiFiGeneric.h>
#include <ESP8266WiFiAP.h>
#include "Ticker.h"
#include <TZ.h>
//#include <WiFiUdp.h>
//#include <WiFiClientSecure.h>
//#include "WiFiClientPrint.hpp"
#include <FS.h>   // Include the SPIFFS library
#include "base64.h"
#include "libb64/cdecode.h"
#include "AsyncArduinoJson.h"

enum ContentType : uint8 {TEXT_PLAIN = 0, TEXT_HTML, TEXT_CSS, APP_JAVASCRIPT, APP_JSON, IMAGE_SVG, IMAGE_PNG, IMAGE_JPEG};
static const char* ContentTypeStr[] PROGMEM = {"text/plain", "text/htm", "text/css", "application/javascript", "application/json", "image/svg+xml", "image/png", "image/jpeg"};
static const char* ContentTypeExt[] PROGMEM = {"", ".htm", ".css", ".js", ".json", ".svg", ".png", ".jpeg"};
static const char* HTTPMethodStr[] PROGMEM = { "HTTP_ANY", "HTTP_GET", "HTTP_HEAD", "HTTP_POST", "HTTP_PUT", "HTTP_PATCH", "HTTP_DELETE", "HTTP_OPTIONS" };

inline const char* PROGMEM getContentTypeStr(ContentType contentType) { return ContentTypeStr[contentType]; }
inline const char* PROGMEM getContentTypeExt(ContentType contentType) { return ContentTypeExt[contentType]; }

/*enum ItemType {ItemUnknown = 0, ItemCall = 1, ItemColor = 2, ItemContact = 4, ItemDateTime = 8, ItemDimmer = 16, ItemGroup = 32, ItemLocation = 64, ItemNumber = 128,\
	ItemRollerShutter = 256, ItemString = 512, ItemSwitch = 1024}; */
enum ItemType : uint16 {ItemUnknown = 0, ItemCall, ItemColor, ItemContact, ItemDateTime, ItemDimmer, ItemGroup, ItemLocation, ItemNumber,\
	ItemRollerShutter, ItemString, ItemSwitch};
static const char *ItemTypeStr[] PROGMEM = {"", "Call", "Color", "Contact", "DateTime", "Dimmer", "Group", "Location", "Number",\
	"Rollershutter", "String", "Switch"};
enum GroupFunction : uint8 {FunctionNone = 0, FunctionAVG, FunctionOR};
#define isNumber(x) ((x == ItemNumber) || (x == ItemDimmer))

#ifdef OpenHABDebug
template <typename T, typename U> static inline void DbgPrint(T x, U y) {Serial.print(x); Serial.print(y);}
template <typename T, typename U> static inline void DbgPrintln(T x, U y) {Serial.print(x); Serial.println(y);}
template <typename T> static inline void DbgPrintln(T x) {Serial.println(x);}
template <typename T> static inline void DbgPrint(T x) {Serial.print(x);}
ICACHE_FLASH_ATTR static inline void DbgPrintf(const char *format, ...) {
  char sbuf[256];			// For debug lines
  va_list varArgs;          	// For variable number of params
  va_start(varArgs, format);	// Prepare parameters
  vsnprintf(sbuf, sizeof(sbuf), format, varArgs);	// Format the message
  va_end(varArgs);            // End of using parameters
  Serial.print(sbuf);
}
#else	// OpenHABDebug
#define DbgPrint(x)			{}
#define DbgPrintln(x,...)	{}
#define DbgPrintf(const char *format, ... ) {}
#endif	// OpenHABDebug

/* 
// Minimal class to replace std::vector
template<typename Data>
class Vector {
  size_t _size; // Stores no. of actually stored objects
  size_t _capacity; // Stores allocated capacity
  Data *_data; // Stores data
  public:
    Vector() : _size(0), _capacity(0), _data(0) {}; // Default constructor
    Vector(Vector const &orig) : _size(orig._size), _capacity(orig._capacity), _data(0) { _data = (Data *)malloc(_capacity*sizeof(Data)); memcpy(_data, orig._data, _size*sizeof(Data)); }; // Copy constuctor
    ~Vector() { free(_data); }; // Destructor
    Vector &operator=(Vector const &orig) { free(_data); _size = orig._size; _capacity = orig._capacity; _data = (Data *)malloc(_capacity*sizeof(Data)); memcpy(_data, orig._data, _size*sizeof(Data)); return *this; }; // Needed for memory management
    //void push_back(Data const &x) { if (_capacity == _size) resize(); _data[_size++] = x; }; // Adds new value. If needed, allocates more space
    Data *push_back(Data const &x) { if (_capacity == _size) resize(); memcpy((void *)&_data[_size], (const void *)&x, sizeof(Data)); return (Data *)&_data[_size++]; }; // Adds new value. If needed, allocates more space
    size_t size() const { return _size; }; // Size getter
    Data const &operator[](size_t idx) const { return _data[idx]; }; // Const getter
    Data &operator[](size_t idx) { return _data[idx]; }; // Changeable getter
  private:
    void resize() { _capacity = _capacity ? _capacity * 2 : 1; Data *newdata = (Data *)malloc(_capacity*sizeof(Data)); memcpy(newdata, _data, _size * sizeof(Data)); free(_data); _data = newdata; };// Allocates double the old space
};
*/

static const char* connectionStatusStr[] PROGMEM = { "Idle status", "Network not available", "", "Connected", "Wrong password", "", "Disconnected" };
static const char* PROGMEM connectionStatus(uint16_t status){
    if (status < (sizeof(connectionStatusStr) / sizeof(char *)))
      return connectionStatusStr[status];
    return PSTR("Unknown");
}

#define PTM(w) Serial.print(" " #w "="); Serial.print(tm->tm_##w);

extern const PROGMEM char *allowedMAC[];

ICACHE_FLASH_ATTR static void wifiEventHandler(System_Event_t *event) { 
  //System_Event_t* event = reinterpret_cast<System_Event_t*>(arg);
  //DbgPrintln("wifiEventHandler - event:", event->event);
  switch (event->event) {  // A client connected with the SoftAP
    case WIFI_EVENT_STAMODE_CONNECTED:        break;
    case WIFI_EVENT_STAMODE_DISCONNECTED:     
      DbgPrintf("[WiFi] %d, Disconnected - Status %d, %s\n", event, WiFi.status(), connectionStatus(WiFi.status()));      
      break;
    case WIFI_EVENT_STAMODE_AUTHMODE_CHANGE:  break;
  
    // The ESP8266 connected to another AP and got an IP address
    case WIFI_EVENT_STAMODE_GOT_IP: {
      DbgPrintln(F("OpenHab::wifiEventHandler - WIFI_EVENT_STAMODE_GOT_IP"));
      Event_StaMode_Got_IP_t gotIP = event->event_info.got_ip;
      //gotIP.mask; gotIP.gw
      DbgPrintln(F("ESP IP Address on Router AP: "), IPAddress(gotIP.ip.addr).toString());
      //OpenHabServer.SetIP(IPAddress(gotIP.ip.addr));
      break;
    }
    //case WIFI_EVENT_SOFTAPMODE_STADISCONNECTED:
    case WIFI_EVENT_SOFTAPMODE_STACONNECTED: {
      DbgPrintln(F("OpenHab::wifiEventHandler - WIFI_EVENT_SOFTAPMODE_STACONNECTED"));
      char macStr[20];
      snprintf(macStr, 20, MACSTR, MAC2STR(event->event_info.sta_connected.mac));
      DbgPrintln(F("ESP AP Client MAC address: "), macStr);
      for (int i = 0; allowedMAC[i]; i++) {
        if (strcmp(macStr, allowedMAC[i]) == 0) return;
      }
      // This MAC address is not allowed to connect
      DbgPrintln(F("Illegal MAC address, shutting down AP"));
      WiFi.softAPdisconnect(false);
      delay(1000);
      break;
    }
  }
}
//static void handleRequest(AsyncWebServerRequest *request){}

class OpenHab {
public:
	struct Sitemap {
		const char *link;
		const JsonVariant obj;
		Sitemap *next;
	};
	struct ItemReference {
		const JsonVariant obj;
		const JsonVariant widgetObj;
		ItemReference *next;		
	};
	struct Item {
		const char *name;
		const char *link;
		char *state;
		const char* label;
		const JsonVariant obj;
		const JsonVariant widgetObj;
		ItemReference *referenceList;
		Sitemap *sitemap;
		Item *next;
		ItemType type;
		//ItemType type : 15;	bool labelIsFormatted : 1;
	};
	struct TopLevelSitemap {
		//const char *name;
		String name;
		DynamicJsonDocument jsonDoc;
		Sitemap *sitemapList;
		//TopLevelSitemap *next;
	};
	struct ItemList {
		Item* item;
		ItemList *next;		
	};
	struct Group {
		const char *name;
		Item *item;
		ItemType groupType;
		GroupFunction groupFunction;
		ItemList *itemList;
		Group *next;
	};
	struct Subscription {
		uint32_t clientIP;
		//AsyncWebServerRequest &request;
		AsyncEventSource events;
		Subscription *next;
		//const char uuidStr[37];
		char *uuidStr;
		//byte uuid[16];
	};

	/*
	template <ItemType T>
	class Item2 {
		public:
			void get<T>();
			void set<T>();
		protected:
			struct T _itemData;
	};
	*/

	OpenHab(const int port = 80);
	bool Init(const char *ssid, const char *APssid, const char* passphrase, const char* allowedMAC[] = {}, const char *local_ip = "", const char *gateway = "", const char *subnet = "");
	void StartServer();
	//ICACHE_FLASH_ATTR void Items(char *itemsJson, const size_t size = 256);
	void HandleClient();

protected:
	AsyncWebServer _server;
	const int _port;
	IPAddress _espIP;
	//WiFiClientPrint<256> _print;
	Ticker _currentDateTimer;
	TopLevelSitemap *_topLevelSitemapList;
	Item *_itemList;
	Group *_groupList;			
	Subscription *_subscription = nullptr;
	struct tm *_currentDateTime;
	const char **_allowedMAC;

	//void convDateTimeJavaToC(char *dateTime);
	char *getCurrentDateTime();
	void serverSentEventHeader(AsyncResponseStream &response);
	//void serverSentEvent(WiFiClient client);
	void SSEPageUpdate(JsonVariant obj);
	void SSEKeepAlive(const char *sitemap, const char *pageId);
	void SSEEventHandler(AsyncWebServerRequest &request);
	Group *newGroup(const char *name, Item *item, ItemType type);
	Group *addItemToGroup(const char *name, Item *item);
	Group *getGroup(const char *name);
	Item *getItem(const char *name);
	void newItem(JsonVariant itemObj, JsonVariant widgetObj, Sitemap *sitemap);
	float functionAVG(ItemList *itemList);
	const char *functionOR(Group* group, int *numItems);
	void setGroupState(const char *groupName);
	void setState(Item *item, const char *state, bool updateGroup = true);
	void setState(Item *item, float f, uint8 precision = 6, bool updateGroup = true);
	void updateLabel(Item *item, int numItems = -1);
	void SendJson(AsyncWebServerRequest &request, JsonVariant obj);
	void SendFile(AsyncWebServerRequest &request, String fname, const boolean isFinal = true, ContentType contentType = APP_JSON);
	TopLevelSitemap *GetSitemapsFromFS();
	void registerLinkHandlers(const JsonVariant prototype, TopLevelSitemap *sitemap);
	void handleSitemaps(AsyncWebServerRequest &request, TopLevelSitemap *sitemapList);
	void handleSubscribe(AsyncWebServerRequest &request);
	void handleSitemap(AsyncWebServerRequest &request, const char *uri);
	void handleAll(AsyncWebServerRequest *request);

	ICACHE_FLASH_ATTR void handleNotFound(AsyncWebServerRequest &request, const char* uri);
	void handleItem(AsyncWebServerRequest &request, const char *uri);
	//DynamicJsonDocument getJsonDocFromFile(const char *fileName); // DeserializationError& error);
	DynamicJsonDocument getJsonDocFromFile(String fileName); // DeserializationError& error);
	JsonVariant getNestedMember(const JsonVariant prototype, const char *key);
	//JsonVariant cloneInPlace(JsonBuffer& jb, JsonVariant prototype);
	//ICACHE_FLASH_ATTR JsonObject containsNestedKey(const JsonObject obj, const char* key);
	ItemType getItemType(const char *itemTypeStr) {
		int middle, first = 0, last = sizeof(ItemTypeStr)/sizeof(ItemTypeStr[0]) - 1;
		do {
			middle = (first + last) >> 1;
			int cmp = strcmp_P(ItemTypeStr[middle], itemTypeStr);
			if (cmp == 0) return (ItemType) middle; //(1 << --middle);
			else if (cmp < 0) first = middle + 1;
			else last = middle - 1;
		} while (first <= last);
		return ItemUnknown;
	};

	#ifdef OpenHABDebug
	ICACHE_FLASH_ATTR void DbgPrintRequest(AsyncWebServerRequest &request, String str) {
		String message = F("\nDbgPrintRequest - URI: ");
		message + request.url(); message += F(" - METHOD: ");
		message += HTTPMethodStr[request.method()];	message += F("  - ARGUMENTS: ");
		for (uint8_t i = 0; i < request.args(); i++) {
			message += request.argName(i); message += F(" = ");
			message += request.arg(i); message += F("; ");
		}
		DbgPrintln(str, message);
	}
	#else
	#define DbgPrintRequest(x,y)	{}
	#endif
};
#endif // OpenHABInclude